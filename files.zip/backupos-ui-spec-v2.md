# BackupOS UI Design Spec v2

Supersedes v1. Same OS Family shell and tokens — this document **adds** features, improves existing ones, specs the profile/security system, expands the logging story, and delivers the logo assets.

Read v1 first for foundational tokens and shell rules. This doc focuses on what changed and what's new.

---

## Part 1 — New features

### 1.1 Restore verification (scheduled restore tests)

The feature that kills "Schrödinger's backup." V1, not V2.

**The problem:** A backup that never gets restored is worthless. Restic check verifies repo integrity, not that your backup is *usable*.

**The feature:** Scheduled automated restore tests. Pick a job, pick a target (an isolated LXC, a temp directory, a Docker volume on a sandbox host), schedule how often (weekly default), and BackupOS runs an actual restore into the sandbox, runs a user-defined validation hook (e.g. `psql -c "SELECT COUNT(*) FROM users"`), records the result, and tears the sandbox down.

**UI:**
- New page: **Verification** (under `BACKUP` nav group, between Snapshots and Agents)
- Page layout identical to Jobs: list view with status · name · job · target · schedule · last result · next run
- Each test has a detail page showing a chart of pass/fail over time, plus full logs from each run
- Test creation wizard (4 steps): Pick job → Pick sandbox target → Validation hook → Schedule
- Sandbox target types: temp directory on agent, Docker volume on agent, Proxmox VM clone (requires hypervisor driver), SSH target

**Alert rule added:** `verification_failed` — fires on any failed restore test.

**Dashboard addition:** New KPI tile "Verified backups" showing % of jobs with a passing restore test in the last 7 days. Red when under 80%.

---

### 1.2 Disaster Recovery mode

**The problem:** When things go wrong, you're stressed, and a dashboard isn't what you need. You need a runbook.

**The feature:** A dedicated DR Mode view (top-right toggle, keyboard shortcut `⌘⇧D`). Entering DR Mode transforms the UI:
- Everything non-recovery fades to near-invisible
- A guided recovery flow takes over the content area
- Three big cards: "Restore a file", "Restore a database", "Restore a whole host"
- Each flow is a wizard with extra hand-holding, dry-run required before execution, and a "What will this touch?" impact preview

**UI elements:**
- DR Mode toggle in topbar (shield icon, pulses red-dim when any job has failed in last 24h — subtle prompt)
- DR Mode uses a distinct surface tint: `--surf` gets a subtle red-shift to mark context
- Persistent "Exit DR Mode" button top-right when active
- All DR actions are audit-logged with a `dr_mode: true` flag for post-incident review

**Additional:** DR runbook export — any restore spec can be exported as a printable PDF runbook (for the "when Claude is down and production is on fire" scenario). Ironic but useful.

---

### 1.3 Bandwidth and schedule windows

**The problem:** Running a full backup at noon on a metered link kills your household. Running one at 3am on a homelab with a noisy fan wakes you up.

**The feature:** Global and per-job bandwidth throttling + backup windows.

**UI:**
- Settings → Backup defaults → Schedule windows (already in v1) — expanded to include bandwidth profile picker
- New concept: **Bandwidth profiles** (e.g. "Quiet hours: 2 MB/s", "Business hours: 10 MB/s", "Unlimited: off"). User-defined.
- Profiles have time-of-day rules: e.g. 00:00–06:00 "Unlimited", 06:00–09:00 "Quiet hours", 09:00–22:00 "Business hours"
- Job-level override: any job can pick its own profile or "inherit global"
- Live bandwidth graph on dashboard (sparkline, last hour, shows throttling in effect with a subtle line)

---

### 1.4 Pre-flight checks

**The problem:** Backup jobs fail because a path doesn't exist, credentials expired, or the repo is full. You only find out at 3am when the alert fires.

**The feature:** Every job has a "Pre-flight" button that runs all checks without actually backing up:
- Source paths exist and are readable
- Agent is online
- Repo is reachable and has quota
- App hook prerequisites (e.g. `pg_dump` installed, credentials valid)
- Expected backup size vs. repo free space

**UI:**
- [Pre-flight] button in job detail page, next to [Run now]
- Pre-flight runs in a modal with live checklist
- Green ticks, red crosses, amber warnings
- Scheduled jobs can be configured to run pre-flight 15min before their scheduled time — if any check fails, fires a `preflight_failed` alert so you can fix before the backup window

**Settings:** `Automatically run pre-flight checks 15 minutes before scheduled runs` toggle (default on).

---

### 1.5 Snapshot tagging, pinning, and retention holds

**The problem:** Restic forget policies are blunt. You want to keep "the snapshot from right before the big migration" forever without writing a custom retention rule.

**The feature:** Three levels of snapshot protection:
- **Tags** — arbitrary labels for organisation (e.g. `pre-upgrade`, `monthly-archive`, `compliance`)
- **Pin** — a single toggle that means "never forget this snapshot regardless of policy"
- **Retention hold** — pin with an expiry date (e.g. "hold until 2027-01-01 for audit")

**UI additions to Snapshots page:**
- Snapshot row actions include Tag · Pin · Hold (new)
- Pinned snapshots show a pin icon; held snapshots show a lock icon with expiry tooltip
- Filter dropdown adds "Only pinned", "Only held", "Has tag"
- Bulk select: tag, pin, hold multiple snapshots at once

**Retention policy editor update:** The forget policy preview now shows "X snapshots protected by pins, Y by holds" so users understand what's excluded.

---

### 1.6 Growth forecasting (cost analytics v2)

**The problem:** "Is my backup cost going to double next year?"

**The feature:** Project storage growth and cost forward based on observed growth rate.

**UI:**
- Repositories detail page gets a new "Forecast" card showing line chart with two series:
  - Actual storage used (last 90 days)
  - Forecast (next 12 months) with confidence band
- Cost forecast below: "Estimated cost in 12 months: $14.20/mo" (vs current $6.80)
- Forecast accounts for retention policy: "With current forget policy, storage plateaus at ~340 GB around month 7"
- If forecast exceeds user's cost budget, banner appears: "Projected cost will exceed your $10/mo budget in 5 months. View suggestions →"

**Suggestions engine:**
- "Tighten retention policy" — preview impact
- "Switch backend" — cost comparison against all supported backends
- "Enable compression" — if not already on
- "Exclude large files" — top 10 contributors to growth with option to add exclusion patterns

---

### 1.7 Global search (⌘K)

The topbar already has a search bar. Spec what it actually does:

**The feature:** Fuzzy global search across: jobs, snapshots, repositories, agents, restore specs, alerts, audit events, and settings.

**UI:**
- ⌘K opens full-screen overlay (not sidebar drawer — full search is the focus)
- Input field at top, 48px tall, `--text-lg`
- Results grouped by type under section headers
- Each result shows icon · primary label · secondary metadata · action hint
- Keyboard navigation: ↑↓ to move, ↵ to activate, ⌘K or Esc to dismiss
- Recent searches saved locally, shown when input is empty
- Command actions also searchable: "Enrol agent", "Create job", "Run pre-flight on [job]", etc. These appear in a "Commands" section

---

### 1.8 Live run streaming + session replay

**The problem:** You want to watch a backup happen. Or later, review exactly what happened.

**The feature:** Every run page shows a live log stream with timestamps. Completed runs preserve the full session (stored compressed) so you can scrub through it later.

**UI:**
- Run detail view (already specced in v1) gains a **timeline scrubber** at bottom for completed runs
- Scrubber shows phases: pre-hook → backup → post-hook → verification, with timing bars
- Drag scrubber → log view jumps to that moment
- "Jump to error" button if run failed, takes you to the failure point
- "Copy as command" button — for the restic invocation, useful for debugging

---

### 1.9 Encryption key escrow

**The problem:** Repository passwords can't be recovered. Users lose them. BackupOS should protect users from themselves.

**The feature:** Optional encrypted escrow of repo passwords, guarded by the user's TOTP.

**UI:**
- Add repository wizard gets a new step: "Key escrow (optional)"
- Explains: "BackupOS can store an encrypted copy of this password. Decrypting it requires your TOTP code. If you lose your password, you can recover it using your TOTP. If you lose both, the backup is unrecoverable."
- Toggle. If on, password is encrypted with a key derived from user account + current TOTP secret
- Repository detail page shows "Password in escrow ✓" or "No escrow — password loss will destroy this backup ⚠"
- Recovery flow at Settings → Security → Recover repository password

This is a meaningful differentiator vs. raw Restic. Many users opt out of encryption *because* they're scared of losing the password.

---

### 1.10 Infra OS service-aware backups (V1, previously V3)

Originally deferred to V3 but worth pulling forward for the killer workflow. Light version only:

**The feature:** When Infra OS is connected, BackupOS can auto-suggest backup jobs based on detected services.

**UI:**
- Dashboard adds a card "Services without backups" — lists Infra OS-detected services that have no backup job targeting them
- Each entry has a one-click "Create recommended job" action that opens the new-job wizard pre-filled

Full auto-provisioning (policies, rules) stays in V2. This is just the suggestion engine.

---

### 1.11 Health score

**The problem:** "Is my backup setup actually good?" is a question that requires clicking through six pages.

**The feature:** A single health score (0–100) for the whole BackupOS instance, prominently displayed on the dashboard.

**Score factors:**
- % of jobs with a successful run in last 24h × weight
- % of repos with a recent integrity check × weight
- % of jobs with a passing restore verification × weight
- % of critical services (from Infra OS) with a backup job × weight
- Number of open alerts (negative)
- Agent online % × weight

**UI:**
- Dashboard hero: big score with letter grade (A+, A, B, C, D, F)
- Click to open a breakdown modal showing each factor's contribution and what to fix to improve
- Historical sparkline below score (last 30 days)
- Grade turns red if drops below C

---

## Part 2 — Improvements to existing features

### 2.1 Jobs — improvements

- **Job dependencies:** Job A runs → Job B runs after A succeeds. Useful for multi-tier backups (DB dump first, then filesystem of DB host). New field in Schedule step: "Run after: [picker]"
- **Job templates:** Save a job config as a template. When adding a new job, offer "Start from template" alongside "Blank"
- **Job health badges at row level:** status column shows not just last-run status but a 7-day strip (7 little dots, green/red/missed) for pattern recognition
- **Bulk operations:** select multiple jobs → pause, resume, run, delete

### 2.2 Repositories — improvements

- **Repository groups:** Tag repos with environments (prod, home, lab) and filter dashboard by group
- **Multi-backend replication view:** Restic doesn't support native mirroring but BackupOS can show "this repo is copied to R2 and to a local NAS via rclone" as a read-only fact
- **Dedup ratio visualisation:** Each repo card shows a small bar: [compressed] [deduped] [overhead] as a stacked segment

### 2.3 Snapshots — improvements

- **Diff view:** Select two snapshots of the same job → see what files changed, were added, or deleted. Tree view with +/- indicators
- **Size by path:** For any snapshot, show a treemap visualisation of what's taking space. Helps identify "oh, this log directory is eating my backup"
- **Restore preview:** Before restoring, show "This will write N files totalling X GB to target"

### 2.4 Agents — improvements

- **Agent auto-update channel picker:** Stable / Beta / Pinned. Per-agent or global default
- **Agent capabilities badges:** VSS, hypervisor driver, app hooks available, etc. visible at a glance
- **Agent resource usage:** CPU/RAM/disk I/O of the agent process itself, last 24h sparkline on detail drawer. Important because backups shouldn't kill the host
- **Agent logs** — separate from run logs. The agent's own operational log, streamed live

### 2.5 Monitors — improvements

- **Unified timeline:** Rather than separate detail pages, a unified "all backup activity" timeline view that interleaves BackupOS runs + PBS + Borg results chronologically
- **Monitor groups:** Same grouping concept as repos
- **"Promote to managed"** — For PBS, a button that offers to migrate the backup target into BackupOS-managed (preserving history where possible). Deferred to V2 execution, UI stub in V1

### 2.6 Restore specs — improvements

- **Spec library:** Pre-made example specs for common scenarios (Postgres DR, Docker stack DR, full-host DR) — fork-to-customise pattern
- **Spec variables:** `${SNAPSHOT_ID}`, `${DATE}`, `${HOST}` — resolved at run time
- **Step marketplace (V2 stub):** Share specs with community. UI stub only for V1.

### 2.7 Alerts — improvements

- **Alert grouping:** If 10 jobs all fail because the repo is unreachable, group into one parent alert with 10 children. Dashboard shows parent only
- **Alert snoozing:** Snooze for 1h / 4h / 24h / until date. Better than raw mute
- **Webhook channels alongside email:** Discord, Slack, generic webhook (V1 — upgraded from V2)
- **Alert routing rules:** Different rules → different channels. e.g. verification failures → Discord, everything else → email

---

## Part 3 — Profile, avatar, phone, TOTP

### 3.1 Profile menu

**Trigger:** Avatar button in the **sidebar bottom stack** (not topbar — that's an OS Family rule). Clicking opens a popover, not a dropdown, with richer layout.

**Popover content** (280px wide, anchored to the avatar):

```
┌────────────────────────────────────────┐
│  [avatar 48px]  Darius Vorster          │
│                 darius@homelabza.com    │
│                 Solo · v0.4.0           │
├────────────────────────────────────────┤
│  👤  Profile                     →     │
│  🔐  Security                    →     │
│  💳  Billing                     →     │
│  🔑  API tokens                  →     │
├────────────────────────────────────────┤
│  🌓  Theme                       auto ▾│
│  ⚙️   Settings                    →     │
├────────────────────────────────────────┤
│  ↩️   Sign out                          │
└────────────────────────────────────────┘
```

- Avatar row: 48px avatar, name `--text-md`, email `--text-xs --fg-mute`, tier subline `--text-xs --fg-dim`
- Menu items: 36px rows, icon + label + chevron, hover `--surf2`
- Theme toggle: inline cycle (auto / light / dark) without navigation
- Sign out in danger-dim hover state (`--err-dim` on hover, `--err` text)

### 3.2 Avatar

**Avatar component spec:**

- Shape: circle, sizes 24 / 32 / 48 / 80
- Sources in priority order:
  1. Uploaded image (stored in `/data/avatars/{userId}.webp` self-hosted; S3 in Cloud tier)
  2. Gravatar (by email hash) — **opt-in only**, privacy-preserving default
  3. Generated initial avatar — background colour derived from name hash using a fixed palette of 8 colours, white initials, 500 weight
- Upload flow: drag-and-drop or click to upload, client-side crop to square, resize to 256×256 WebP, max 1 MB accepted
- No border/ring on avatar anywhere (OS Family rule)

### 3.3 Profile page (`/settings/profile`)

Layout: single column, max width 640px, sections separated by `--space-8`.

**Section: Avatar**
- Current avatar 80px on left
- Three actions stacked: [Upload image] · [Use Gravatar] · [Remove]
- Helper text: "Self-hosted: stored locally. Cloud: stored in your account."

**Section: Personal information**
- Full name (required, `--text-base` input)
- Display name (optional, shown in UI if set, else full name)
- Email (locked, "Change email" link opens modal requiring current password + verification)
- Phone number (new — see §3.4)
- Timezone (dropdown, defaults to browser)
- Language (dropdown, V1 = English only, future-ready field)

**Section: Contact preferences**
- Email notifications (master toggle)
- SMS notifications (toggle, requires verified phone)
- Per-category toggles: Alerts, Weekly summary, Product updates

Save button is sticky at the bottom of the form area when unsaved changes exist.

### 3.4 Phone number system

**Why it matters:**
- SMS 2FA fallback (TOTP primary, SMS backup)
- SMS alert channel (opt-in, critical alerts only)
- Account recovery

**Phone verification flow:**
1. User enters phone in profile → [Send code]
2. Modal: 6-digit code input, resend timer (60s cooldown)
3. Enter code → phone marked verified with green tick in profile
4. Unverified phone never receives SMS — shown with amber warning in profile

**Phone display format:** International E.164 in storage, localised display (e.g. +27 82 123 4567 in ZA format, +1 (305) 555-0100 in US format).

**UI components:**
- Phone input: country code dropdown + number field, inline verified/unverified badge
- Verification code input: 6 separate boxes, auto-advance on keypress, paste handling

**Settings control:** User can delete their phone at any time. Removing a verified phone with SMS 2FA enabled triggers a warning: "Removing this phone will disable SMS as a 2FA method. You'll still have TOTP enabled."

### 3.5 TOTP (security page)

**Page:** `/settings/security` — this replaces the flat "Security" section from v1 with a dedicated page.

**Layout sections (top to bottom):**

#### §1 Password
- Change password (current + new + confirm)
- Last changed: relative time
- Strength meter on new password input

#### §2 Two-factor authentication
Empty state:
```
┌─────────────────────────────────────────────┐
│  Two-factor authentication is off.          │
│  Add a second factor to protect your        │
│  account even if your password is leaked.   │
│                                             │
│  [Enable TOTP]                              │
└─────────────────────────────────────────────┘
```

After TOTP enabled:
```
┌─────────────────────────────────────────────┐
│  ✓ TOTP                            [Remove] │
│    Added Apr 16, 2026                       │
│    Backup codes: 8 remaining                │
│                                             │
│  ✓ SMS backup                      [Remove] │
│    +27 82 ••• 4567 (verified)               │
│                                             │
│  [+ Add another method]                     │
└─────────────────────────────────────────────┘
```

**TOTP enrolment flow (modal, 3 steps):**

*Step 1 — Verify identity*
- "Enter your password to continue" — password re-entry guard
- Prevents someone sitting at an unlocked session from enabling 2FA under your account

*Step 2 — Scan QR*
- Large QR code (256×256) on left
- Secret (manual entry) on right, IBM Plex Mono, monospaced, copy button
- Issuer: "BackupOS ({{instance name}})"
- Account label: email
- Instructions: "Scan with 1Password, Authy, Google Authenticator, or any TOTP app"
- [Continue] button

*Step 3 — Verify and save backup codes*
- 6-digit code input → on valid code, reveal 10 backup codes (IBM Plex Mono grid, 2 cols × 5 rows)
- Each code is single-use, 8 chars: `XXXX-XXXX`
- Three actions: [Copy all] · [Download .txt] · [Print]
- Required checkbox: "I've saved these codes somewhere safe"
- [Finish] button enabled only after checkbox

**Backup codes page:**
- Lists remaining codes (one-way — regenerating invalidates previous batch)
- "Regenerate" button with confirmation modal
- Shows last-used code timestamp

**Trusted devices (V1.1):**
- "Remember this device for 30 days" checkbox on TOTP prompt at login
- List of trusted devices with last-seen IP + user agent
- Revoke per-device

#### §3 Active sessions
Table: device · location (IP → city via GeoIP) · last active · actions
- Current session marked
- Revoke individual sessions
- "Sign out all other sessions" danger button

#### §4 API tokens
- List of personal API tokens with scope badges + last used
- Create token modal: name, scopes (checkbox list), expiry (30d / 90d / 1y / never)
- Token shown once on creation with warning "You will not see this again"

#### §5 Audit scope
- Link to Audit log pre-filtered to "my actions only"
- Exportable

---

## Part 4 — Logging feature (expanded)

BackupOS v1 had `Activity` (user-facing) and `Audit log` (security). v2 adds a proper observability layer.

### 4.1 Three tiers of logging

| Tier | Audience | Content | Retention default | Location |
|---|---|---|---|---|
| **Activity feed** | Users | High-level events: "Darius ran job nightly-postgres" | 90 days | DB table `activity` |
| **Audit log** | Admins / compliance | Security events: logins, permission changes, destructive actions | 1 year (configurable up to forever) | DB table `audit` |
| **Operational logs** | Operators / debuggers | Structured logs from backup engine, agents, web app | 14 days default, configurable | DB table `logs` with JSONL export |

### 4.2 Operational logs — new page

**Route:** `/logs`

**Nav placement:** Under `OVERVIEW` group, between Activity and the start of BACKUP group. Icon: `file-terminal`.

**Layout:**
- Left filter rail (240px): component picker (web, agent-{host}, engine, hypervisor, hook, monitor), level picker (debug/info/warn/error/fatal), time range, free-text search
- Main area: log stream, newest at top by default, scrollable
- Each log entry:
  ```
  timestamp  level-badge  component  message                                [⋯]
  Plex Mono  [INFO]       web        Job nightly-postgres scheduled to run...
  ```
- Click entry → expands to show full structured JSON payload inline, syntax-highlighted
- Top bar: [Live tail] toggle (websocket stream) · [Pause] · [Download] · [Copy filter URL]

### 4.3 Per-entity log views

Every job, agent, repo, monitor, and restore run has a "Logs" tab/section that opens Operational logs pre-filtered to that entity. No navigation required.

### 4.4 Log retention settings

Settings → General → Logging:
- Activity retention: 30d / 90d / 180d / 365d / forever
- Audit retention: 90d / 365d / 3y / 7y / forever
- Operational retention: 7d / 14d / 30d / 90d
- Daily rotation + optional compression (gzip) for operational logs at rest

### 4.5 Log export

- Manual export: any filtered view → [Export] → CSV or JSONL
- Scheduled export: Settings → Logging → "Nightly export to S3" (V2)
- Live streaming: WebSocket endpoint `/api/logs/stream` for piping to Loki/Elasticsearch (V1, documented)

### 4.6 Audit log improvements (over v1)

- **Verb.object ontology expanded** — new event types for 2FA, sessions, API tokens, escrow access
- **Forensic mode** — enter an actor's name, get a full timeline of their actions with inline diffs for config changes
- **Tamper-evidence** — each audit entry is hash-chained to the previous (`prev_hash`, `hash`). Tampering with a row breaks the chain. A `/settings/security` widget shows "Audit chain integrity: ✓ verified 2m ago"
- **Digital signing (V2):** sign each entry with instance private key for external verification

---

## Part 5 — Logo and branding

### 5.1 Logo concept: **Grid Shield**

A 4-quadrant grid meeting at a bright central square, same construction family as ProxyOS Grid Pivot but in amber. The visual metaphor: four "backups" converging to a single point of truth. The bright centre reads as a restore point, a snapshot, a safe harbour.

### 5.2 SVG assets

All logos use a 48×48 viewBox for consistency across the OS Family. Rounded outer radius `rx=16`.

#### Primary mark (48×48)

```svg
<svg width="48" height="48" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
  <rect width="48" height="48" rx="16" fill="#1A1206"/>
  <rect x="6"  y="6"  width="16" height="16" rx="2" fill="#F5A623"/>
  <rect x="26" y="6"  width="16" height="16" rx="2" fill="#854F0B"/>
  <rect x="6"  y="26" width="16" height="16" rx="2" fill="#854F0B"/>
  <rect x="26" y="26" width="16" height="16" rx="2" fill="#C77A14"/>
  <rect x="18" y="18" width="12" height="12" rx="2" fill="#FEF5E0"/>
</svg>
```

- Outer rounded square: `#1A1206` (deep amber-black — 4% more saturated than pure black for warmth)
- Top-left quadrant: bright `#F5A623` (primary accent)
- Top-right: `#854F0B` (dark accent)
- Bottom-left: `#854F0B`
- Bottom-right: `#C77A14` (mid amber — new, bridges light and dark)
- Centre square: `#FEF5E0` (soft cream, same white-point as ProxyOS for cross-family consistency)

The asymmetric placement of the bright quadrant (top-left) gives the mark directionality and visual interest — it's not a mandala, it reads.

#### Wordmark (horizontal)

For use in sidebar, topbar, footer:

```
[Grid Shield 24×24]  BackupOS
```

- Mark: 24×24, `--space-3` (12px) gap
- Wordmark: "BackupOS" in **Inter** 500 weight, 16px, letter-spacing `-0.01em`
- "Backup" in `--fg`, "OS" in `--accent`
- Baseline-aligned with mark centre

For OS Family hub consistency, use the same construction: `[mark] [Product][OS in accent]`.

#### Monochrome variant

For print, embossing, single-colour contexts:

```svg
<svg width="48" height="48" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
  <rect width="48" height="48" rx="16" fill="currentColor"/>
  <rect x="6"  y="6"  width="16" height="16" rx="2" fill="white" fill-opacity="0.95"/>
  <rect x="26" y="6"  width="16" height="16" rx="2" fill="white" fill-opacity="0.30"/>
  <rect x="6"  y="26" width="16" height="16" rx="2" fill="white" fill-opacity="0.30"/>
  <rect x="26" y="26" width="16" height="16" rx="2" fill="white" fill-opacity="0.55"/>
  <rect x="18" y="18" width="12" height="12" rx="2" fill="white"/>
</svg>
```

Uses `currentColor` so it inherits from parent — useful in dark/light contexts.

### 5.3 Favicon

Browser tab icon. Different requirements than the main mark: must be legible at 16×16.

**Strategy:** A simplified version of the Grid Shield that preserves the four-square-plus-centre identity but with thicker strokes and no rounded inner squares.

```svg
<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
  <rect width="32" height="32" rx="6" fill="#1A1206"/>
  <rect x="4"  y="4"  width="10" height="10" fill="#F5A623"/>
  <rect x="18" y="4"  width="10" height="10" fill="#854F0B"/>
  <rect x="4"  y="18" width="10" height="10" fill="#854F0B"/>
  <rect x="18" y="18" width="10" height="10" fill="#C77A14"/>
  <rect x="12" y="12" width="8"  height="8"  fill="#FEF5E0"/>
</svg>
```

Changes from primary:
- Outer `rx=6` instead of 16 (favicons at 16×16 lose the round shape entirely with rx=16; 6 keeps it visible)
- Inner quadrants: no inner radius (sharper at tiny sizes)
- Centre: 8×8 instead of 12×12 proportionally, reads clearly even at 16×16

### 5.4 Favicon delivery bundle

Ship all of these from `/public/` so the browser picks the right one:

```
/public/favicon.ico              ← 16×16 + 32×32 multi-resolution ICO
/public/favicon.svg              ← SVG variant (modern browsers)
/public/icon-192.png             ← Android Chrome
/public/icon-512.png             ← PWA install
/public/apple-touch-icon.png     ← 180×180 for iOS
/public/manifest.webmanifest     ← PWA manifest
```

`manifest.webmanifest`:
```json
{
  "name": "BackupOS",
  "short_name": "BackupOS",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ],
  "theme_color": "#F5A623",
  "background_color": "#0A0A0A",
  "display": "standalone",
  "start_url": "/"
}
```

`<head>` tags in Next.js `app/layout.tsx`:
```tsx
export const metadata = {
  title: 'BackupOS',
  description: 'Unified homelab backup management',
  icons: {
    icon: [
      { url: '/favicon.ico', sizes: 'any' },
      { url: '/favicon.svg', type: 'image/svg+xml' }
    ],
    apple: '/apple-touch-icon.png'
  },
  manifest: '/manifest.webmanifest',
  themeColor: '#F5A623'
}
```

### 5.5 Loading states in tab

Unread-count and processing states in the browser tab favicon:

- Idle: standard favicon
- Running (active backups): animated — centre square pulses opacity 0.6 → 1 → 0.6 every 1.5s (use a canvas-generated dynamic favicon, or swap between two static SVGs)
- Alert (open critical alert): a small red `●` overlaid at top-right of the favicon
- Title prefix: `(2) BackupOS` if 2 critical alerts open, `● BackupOS` if a backup is actively running

Favicon swapping is done from the web app using a `faviconState` store that updates `<link rel="icon">` href.

### 5.6 OG image and social cards

For backupos.app landing page and shared links:

- 1200×630 OG image
- Dark background (`#0A0A0A`) with subtle amber gradient top-left
- Grid Shield mark at 120×120, top-left, `--space-10` padding
- Product tagline large: "Backups that don't lie to you." (48px Inter 500)
- Sub-tagline: "Unified homelab backup management." (20px Inter 400 `--fg-mute`)
- Bottom-right: "backupos.app" in IBM Plex Mono 14px `--fg-dim`
- Optional: faint grid texture overlay at 3% opacity for visual interest

Ship as `/public/og.png`, referenced in metadata.

---

## Part 6 — Updated build priorities

Revised 12-phase order (was 10 in v1):

1. **Shell** — sidebar + topbar + theme tokens + favicon + profile popover shell
2. **Auth + profile + security** — login, password, avatar upload, phone verification, TOTP enrolment, sessions, API tokens. *Before Dashboard* because everything else needs a logged-in user and proper session handling
3. **Dashboard** — KPI cards + health score + recent runs
4. **Agents + enrolment flow**
5. **Repositories + add-repo wizard + key escrow**
6. **Jobs list + detail + new-job wizard + dependencies + templates**
7. **Schedules + bandwidth profiles + pre-flight**
8. **Snapshots browser + tags/pins/holds + diff view**
9. **Restore specs + runs + DR Mode**
10. **Verification (scheduled restore tests)**
11. **Monitors + unified timeline**
12. **Alerts + rules + webhook channels** and **Logging (Activity + Audit + Operational)** in parallel
13. **Settings final pass** — retention, cost budgets, forecasting, Infra OS link

Billing is embedded into Settings → Account (per OS Family standard) and built alongside phase 2.

---

## Part 7 — OS Family compliance checklist (updated)

From v1 plus new rules introduced by v2:

- ✅ All v1 rules still apply
- ✅ Avatar in **sidebar bottom stack**, not topbar
- ✅ Profile popover (not dropdown), anchored to avatar
- ✅ Theme toggle inline in profile popover (auto/light/dark)
- ✅ 2FA enrolment requires password re-entry guard
- ✅ Backup codes forced-save checkbox before completion
- ✅ Favicon has alert/running state variants
- ✅ OG image follows hub visual language
- ✅ Logo mark uses OS Family centre-square convention (same white-point as ProxyOS)
- ✅ Operational logs page uses standard list + filter rail pattern
- ✅ Tamper-evident audit log (hash chain)
- ✅ Structured JSON payload expand pattern on log entries
